"""
GenKey - A simple command-line tool to generate secure keys and passwords.
"""

__version__ = "0.1.0"